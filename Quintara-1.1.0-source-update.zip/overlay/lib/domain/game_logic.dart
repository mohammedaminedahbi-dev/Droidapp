import '../data/word_bank.dart';

enum LetterMark { absent, present, correct }

/// Word scoring follows duplicate-aware two-pass evaluation.
List<LetterMark> evaluateGuess(String guess, String answer) {
  if (guess.length != 5 || answer.length != 5) {
    throw ArgumentError('Both words must contain exactly five letters.');
  }
  final result = List<LetterMark>.filled(5, LetterMark.absent);
  final remaining = <String, int>{};
  for (var i = 0; i < 5; i++) {
    if (guess[i] == answer[i]) {
      result[i] = LetterMark.correct;
    } else {
      remaining[answer[i]] = (remaining[answer[i]] ?? 0) + 1;
    }
  }
  for (var i = 0; i < 5; i++) {
    if (result[i] == LetterMark.correct) continue;
    final count = remaining[guess[i]] ?? 0;
    if (count > 0) {
      result[i] = LetterMark.present;
      remaining[guess[i]] = count - 1;
    }
  }
  return result;
}

bool isValidGuess(String word) =>
    word.length == 5 && validWords.contains(word.toUpperCase());

/// Returns a sequence of distinct, answer-specific letter clues.
/// The caller should increment hintIndex after each purchased hint.
/// Once all clues are used, this returns a clear exhaustion message rather
/// than cycling back to a clue the player has already seen.
String hintFor(String rawAnswer, int hintIndex) {
  final answer = rawAnswer.toUpperCase();
  if (answer.length != 5) {
    throw ArgumentError('The answer must contain exactly five letters.');
  }

  final vowels = 'AEIOU';
  final vowelPositions = <int>[];
  final consonantPositions = <int>[];
  for (var i = 0; i < answer.length; i++) {
    (vowels.contains(answer[i]) ? vowelPositions : consonantPositions)
        .add(i + 1);
  }

  final counts = <String, int>{};
  for (final letter in answer.split('')) {
    counts[letter] = (counts[letter] ?? 0) + 1;
  }
  final repeated = counts.entries.where((e) => e.value > 1).toList();
  final distinct = counts.length;
  final sorted = answer.split('')..sort();
  final alphabetSum = answer.codeUnits.fold<int>(0, (a, b) => a + b);

  final candidates = <String>[
    'The first letter is ${answer[0]}.',
    'The last letter is ${answer[4]}.',
    'There are ${vowelPositions.length} vowel${vowelPositions.length == 1 ? '' : 's'}.',
    'There are ${consonantPositions.length} consonants.',
    'The word uses $distinct different letters.',
    if (repeated.isEmpty) 'Every letter in this word is different.',
    if (repeated.isNotEmpty)
      'At least one letter appears more than once.',
    if (repeated.isNotEmpty)
      'The repeated letter is ${repeated.first.key}.',
    'The middle letter is ${answer[2]}.',
    'The second letter is ${answer[1]}.',
    'The fourth letter is ${answer[3]}.',
    'The first two letters are ${answer.substring(0, 2)}.',
    'The last two letters are ${answer.substring(3)}.',
    if (vowelPositions.isNotEmpty)
      'A vowel appears at position${vowelPositions.length == 1 ? '' : 's'} ${vowelPositions.join(', ')}.',
    if (consonantPositions.isNotEmpty)
      'A consonant appears at position${consonantPositions.length == 1 ? '' : 's'} ${consonantPositions.join(', ')}.',
    'The alphabetically earliest letter is ${sorted.first}.',
    'The alphabetically latest letter is ${sorted.last}.',
    if (answer[0].compareTo(answer[4]) < 0)
      'The first letter comes before the last letter alphabetically.'
    else if (answer[0].compareTo(answer[4]) > 0)
      'The first letter comes after the last letter alphabetically.'
    else
      'The first and last letters are the same.',
    'The letters’ alphabet positions add up to $alphabetSum.',
  ];

  final unique = <String>[];
  for (final clue in candidates) {
    if (!unique.contains(clue)) unique.add(clue);
  }
  if (hintIndex < 0 || hintIndex >= unique.length) {
    return 'You have used all the available clues for this word.';
  }
  return unique[hintIndex];
}
