# Quintara 1.1.0 — source update bundle

This is a **source overlay**, not an APK. It is intended for the existing Flutter repository `mohammedaminedahbi-dev/Droidapp`.

## What this bundle changes
- Renames the visible app branding to **Quintara** (including Android launcher label).
- Updates the app version to `1.1.0+2`.
- Replaces the three-clue cycling hint logic with a larger set of distinct letter/structure clues. It does not cycle back to earlier clues.
- Removes the visible answer from the failed-game dialog.
- Includes a matching Quintara launcher icon in the common Android mipmap sizes.

## Apply it
1. Download and extract this ZIP.
2. Copy `apply_quintara_update.py` and the `overlay` folder into the root of your Flutter project (the same folder that contains `pubspec.yaml`).
3. Run the script from that folder with Python 3:
   `python apply_quintara_update.py`
4. Then run:
   `flutter pub get`
   `flutter analyze`
   `flutter test`
   `flutter build apk --release`

The script edits only the listed source/manifest/version/icon files. It does not modify your `main` branch automatically; apply it on a separate branch or a copy of the project.

## Important limitations
- This ZIP does **not** contain a compiled APK and has not been compiled or device-tested here.
- AdMob is **not yet included** in this overlay. Before adding ads, the final AdMob App ID and ad unit IDs must be configured, and the privacy notice / Google Play Data safety disclosures must be updated. Do not publish with test ad IDs.
- The app's Dart package name remains `letterforge` so existing imports and local progress compatibility are not broken.
- Back up your project before applying any source update.
