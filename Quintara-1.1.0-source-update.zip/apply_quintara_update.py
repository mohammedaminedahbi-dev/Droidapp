#!/usr/bin/env python3
"""Apply the Quintara 1.1.0 source overlay to a Flutter project root."""
from pathlib import Path
import re, shutil, sys

root = Path.cwd()
required = [root / "pubspec.yaml", root / "lib/main.dart",
            root / "android/app/src/main/AndroidManifest.xml"]
missing = [str(p.relative_to(root)) for p in required if not p.exists()]
if missing:
    print("Run this script from the extracted Flutter project root. Missing:", ", ".join(missing))
    sys.exit(2)

main = (root / "lib/main.dart").read_text(encoding="utf-8")
main = main.replace("LetterForgeApp", "QuintaraApp")
main = main.replace("LETTERFORGE", "QUINTARA")
main = main.replace("LetterForge", "Quintara")
main = main.replace("Letterforge", "Quintara")
main = main.replace("'The word was $answer. Every guess makes you sharper.'",
                    "'No worries. Every guess helps you improve. Try another round!'")
main = re.sub(r"\s*Text\('Answer: \$answer',style:const TextStyle\(fontWeight:FontWeight\.w900,letterSpacing:3\)\),", "", main)
(root / "lib/main.dart").write_text(main, encoding="utf-8")

manifest_path = root / "android/app/src/main/AndroidManifest.xml"
manifest = manifest_path.read_text(encoding="utf-8").replace('android:label="LetterForge"', 'android:label="Quintara"')
manifest_path.write_text(manifest, encoding="utf-8")

pubspec_path = root / "pubspec.yaml"
pubspec = pubspec_path.read_text(encoding="utf-8")
pubspec = re.sub(r"(?m)^version:\s*.*$", "version: 1.1.0+2", pubspec)
pubspec = re.sub(r"(?m)^description:\s*.*$", "description: Quintara — a five-letter word puzzle game.", pubspec)
pubspec_path.write_text(pubspec, encoding="utf-8")

overlay = Path(__file__).parent / "overlay"
shutil.copy2(overlay / "lib/domain/game_logic.dart", root / "lib/domain/game_logic.dart")
for folder in ["mipmap-mdpi","mipmap-hdpi","mipmap-xhdpi","mipmap-xxhdpi","mipmap-xxxhdpi"]:
    target = root / "android/app/src/main/res" / folder
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy2(overlay / "android/app/src/main/res" / folder / "ic_launcher.png", target / "ic_launcher.png")

print("Quintara source overlay applied.")
print("Next: run flutter pub get, flutter analyze, flutter test, then build an APK.")
print("NOTE: This overlay does not add AdMob yet. AdMob requires a configured app ID, ad unit IDs, consent/privacy disclosures, and a separate tested integration.")
